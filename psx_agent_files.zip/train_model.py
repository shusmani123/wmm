"""
Train the PSX AI model.

Before running:
1. Create training_data.csv in this same folder.
2. It must include numeric feature columns and:
       target_hit_before_stop
3. Run:
       python train_model.py

The model will be saved to:
       models/psx_ai_model.joblib
"""

from psx_level5_ai_agent import train_example_model

train_example_model(
    csv_path="training_data.csv",
    out_path="models/psx_ai_model.joblib",
)
