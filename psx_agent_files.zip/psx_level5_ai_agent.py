"""
PSX Level-5 Shariah AI Market Intelligence Agent

Beginner-ready alert-only agent.

Files expected in the same folder:
- .env
- shariah_universe.txt
- sector_map.csv
- event_calendar.csv
- models/psx_ai_model.joblib  optional after training

Run:
    python psx_level5_ai_agent.py

Important:
- This is alert-only decision support, not guaranteed profit.
- It does not place buy/sell orders.
- Start with paper trading only.
"""

from __future__ import annotations

import asyncio
import csv
import hashlib
import json
import logging
import math
import os
import re
import signal
import statistics
from collections import defaultdict, deque
from dataclasses import dataclass, field
from datetime import date, datetime, time, timedelta
from pathlib import Path
from typing import Any, Deque, Dict, Iterable, Optional
from zoneinfo import ZoneInfo

import numpy as np
import pandas as pd
import requests
import websockets
from bs4 import BeautifulSoup
from dotenv import load_dotenv

try:
    import feedparser
except Exception:
    feedparser = None

try:
    import joblib
except Exception:
    joblib = None


# =============================================================================
# CONFIG
# =============================================================================

load_dotenv()

KARACHI_TZ = ZoneInfo("Asia/Karachi")

PSX_WS_URL = os.getenv("PSX_WS_URL", "wss://psxterminal.com/")
PSX_API_BASE = os.getenv("PSX_API_BASE", "https://psxterminal.com/api")
PSX_DPS_BASE = os.getenv("PSX_DPS_BASE", "https://dps.psx.com.pk")
MARKET_TYPE = os.getenv("PSX_MARKET_TYPE", "REG")

WATCHLIST = [
    s.strip().upper()
    for s in os.getenv(
        "PSX_WATCHLIST",
        "HUBC,MARI,OGDC,LUCK,ENGRO,FFC,PSO,SYS,ATRL,SEARL",
    ).split(",")
    if s.strip()
]

TELEGRAM_BOT_TOKEN = os.getenv("TELEGRAM_BOT_TOKEN", "")
TELEGRAM_CHAT_ID = os.getenv("TELEGRAM_CHAT_ID", "")

REQUIRE_SHARIAH_WHITELIST = os.getenv("REQUIRE_SHARIAH_WHITELIST", "true").lower() == "true"
SHARIAH_UNIVERSE_FILE = Path(os.getenv("SHARIAH_UNIVERSE_FILE", "shariah_universe.txt"))
SECTOR_MAP_FILE = Path(os.getenv("SECTOR_MAP_FILE", "sector_map.csv"))
EVENT_CALENDAR_FILE = Path(os.getenv("EVENT_CALENDAR_FILE", "event_calendar.csv"))
AI_MODEL_PATH = Path(os.getenv("AI_MODEL_PATH", "models/psx_ai_model.joblib"))

NEWS_RSS_URLS = [u.strip() for u in os.getenv("NEWS_RSS_URLS", "").split(",") if u.strip()]

ROLLING_TICKS = int(os.getenv("ROLLING_TICKS", "160"))
MIN_TICKS_FOR_SIGNAL = int(os.getenv("MIN_TICKS_FOR_SIGNAL", "35"))
ALERT_COOLDOWN_MINUTES = int(os.getenv("ALERT_COOLDOWN_MINUTES", "20"))

MIN_PRICE = float(os.getenv("MIN_PRICE", "5"))
MIN_TRADE_VALUE_PKR = float(os.getenv("MIN_TRADE_VALUE_PKR", "250000"))
MAX_SPREAD_PCT = float(os.getenv("MAX_SPREAD_PCT", "0.60"))
MAX_POSITION_RISK_PCT = float(os.getenv("MAX_POSITION_RISK_PCT", "0.50"))

ENTRY_ZONE_BUFFER_PCT = float(os.getenv("ENTRY_ZONE_BUFFER_PCT", "0.25"))
HOLD_CONFIRM_TICKS = int(os.getenv("HOLD_CONFIRM_TICKS", "5"))
HOLD_CONFIRM_SECONDS = int(os.getenv("HOLD_CONFIRM_SECONDS", "60"))
MAX_PENDING_SECONDS = int(os.getenv("MAX_PENDING_SECONDS", "240"))

MOMENTUM_PCT = float(os.getenv("MOMENTUM_PCT", "0.65"))
VOLUME_SPIKE_MULTIPLE = float(os.getenv("VOLUME_SPIKE_MULTIPLE", "2.0"))
BREAKOUT_BUFFER_PCT = float(os.getenv("BREAKOUT_BUFFER_PCT", "0.20"))
STOP_LOSS_PCT = float(os.getenv("STOP_LOSS_PCT", "1.00"))
TARGET1_R = float(os.getenv("TARGET1_R", "1.50"))
TARGET2_R = float(os.getenv("TARGET2_R", "2.50"))

WATCH_CONFIDENCE = float(os.getenv("WATCH_CONFIDENCE", "62"))
TRADE_CONFIDENCE = float(os.getenv("TRADE_CONFIDENCE", "72"))
STRONG_TRADE_CONFIDENCE = float(os.getenv("STRONG_TRADE_CONFIDENCE", "82"))

BOARD_MEETING_DANGER_DAYS = int(os.getenv("BOARD_MEETING_DANGER_DAYS", "1"))
EX_DATE_DANGER_DAYS = int(os.getenv("EX_DATE_DANGER_DAYS", "3"))
NEWS_LOOKBACK_MINUTES = int(os.getenv("NEWS_LOOKBACK_MINUTES", "5"))
REFRESH_CONTEXT_SECONDS = int(os.getenv("REFRESH_CONTEXT_SECONDS", "300"))

MANUAL_HOLIDAYS = {d.strip() for d in os.getenv("PSX_HOLIDAYS", "").split(",") if d.strip()}


# =============================================================================
# LOGGING
# =============================================================================

logging.basicConfig(level=logging.INFO, format="%(asctime)s | %(levelname)s | %(message)s")
logger = logging.getLogger("psx-level5-agent")


# =============================================================================
# UTILS
# =============================================================================

def now_karachi() -> datetime:
    return datetime.now(KARACHI_TZ)


def clamp(value: float, low: float, high: float) -> float:
    return max(low, min(high, value))


def pct_change(new: float, old: float) -> float:
    if old <= 0:
        return 0.0
    return ((new - old) / old) * 100


def safe_float(value: Any, default: float = 0.0) -> float:
    try:
        if value is None:
            return default
        if isinstance(value, str):
            value = value.replace(",", "").replace("%", "").strip()
        return float(value)
    except Exception:
        return default


def hash_text(text: str) -> str:
    return hashlib.sha256(text.encode("utf-8", errors="ignore")).hexdigest()[:16]


def read_symbol_file(path: Path) -> set[str]:
    if not path.exists():
        return set()
    symbols: set[str] = set()
    for line in path.read_text(encoding="utf-8", errors="ignore").splitlines():
        line = line.strip().upper()
        if not line or line.startswith("#"):
            continue
        for part in re.split(r"[,\s]+", line):
            part = part.strip().upper()
            if part:
                symbols.add(part)
    return symbols


def is_psx_regular_market_open(now: Optional[datetime] = None) -> bool:
    """
    PSX regular market timing gate.
    Update this if PSX changes trading hours.
    """
    now = now or now_karachi()

    if now.date().isoformat() in MANUAL_HOLIDAYS:
        return False

    weekday = now.weekday()
    current = now.time()

    if weekday in {5, 6}:  # Saturday/Sunday
        return False

    if weekday in {0, 1, 2, 3}:  # Monday-Thursday
        return time(9, 32) <= current <= time(15, 30)

    if weekday == 4:  # Friday
        return (time(9, 17) <= current <= time(12, 0)) or (
            time(14, 32) <= current <= time(16, 30)
        )

    return False


# =============================================================================
# DATA MODELS
# =============================================================================

@dataclass
class Tick:
    symbol: str
    price: float
    volume: float = 0.0
    bid: Optional[float] = None
    ask: Optional[float] = None
    timestamp: datetime = field(default_factory=now_karachi)

    @property
    def trade_value(self) -> float:
        return self.price * self.volume

    @property
    def spread_pct(self) -> Optional[float]:
        if self.bid is None or self.ask is None or self.bid <= 0 or self.ask <= 0:
            return None
        mid = (self.bid + self.ask) / 2
        if mid <= 0:
            return None
        return ((self.ask - self.bid) / mid) * 100


@dataclass
class NewsItem:
    source: str
    title: str
    summary: str
    published_at: datetime
    url: str = ""
    symbols: list[str] = field(default_factory=list)
    sentiment: float = 50.0
    importance: float = 0.0
    event_type: str = "news"


@dataclass
class CorporateEvent:
    symbol: str
    event_type: str
    event_date: date
    details: str = ""
    importance: float = 0.0


@dataclass
class MarketContext:
    market_score: float = 50.0
    market_breadth_score: float = 50.0
    sector_scores: dict[str, float] = field(default_factory=dict)
    global_macro_score: float = 50.0
    fipi_lipi_score: float = 50.0
    news_items: list[NewsItem] = field(default_factory=list)
    corporate_events: list[CorporateEvent] = field(default_factory=list)
    refreshed_at: datetime = field(default_factory=now_karachi)


@dataclass
class FeatureVector:
    symbol: str
    sector: str
    price: float
    spread_pct: float
    liquidity_score: float
    technical_score: float
    volume_score: float
    market_score: float
    sector_score: float
    news_score: float
    event_score: float
    global_macro_score: float
    fipi_lipi_score: float
    shariah_score: float
    risk_score: float
    historical_model_score: float
    final_confidence: float
    reasons: list[str] = field(default_factory=list)
    dangers: list[str] = field(default_factory=list)


@dataclass
class PendingSetup:
    symbol: str
    setup_time: datetime
    setup_price: float
    entry_low: float
    entry_high: float
    confidence: float
    features: FeatureVector
    hold_ticks: int = 0
    last_seen: datetime = field(default_factory=now_karachi)


@dataclass
class SymbolState:
    ticks: Deque[Tick] = field(default_factory=lambda: deque(maxlen=ROLLING_TICKS))
    last_alert_at: datetime = field(default_factory=lambda: datetime(1970, 1, 1, tzinfo=KARACHI_TZ))
    pending: Optional[PendingSetup] = None

    def add(self, tick: Tick) -> None:
        self.ticks.append(tick)

    def ready(self) -> bool:
        return len(self.ticks) >= MIN_TICKS_FOR_SIGNAL

    def prices(self) -> list[float]:
        return [t.price for t in self.ticks]

    def volumes(self) -> list[float]:
        return [max(t.volume, 0.0) for t in self.ticks]


# =============================================================================
# REFERENCE DATA
# =============================================================================

class ReferenceData:
    def __init__(self) -> None:
        self.shariah_universe = read_symbol_file(SHARIAH_UNIVERSE_FILE)
        self.sector_map = self._load_sector_map(SECTOR_MAP_FILE)
        logger.info("Loaded Shariah universe: %s symbols", len(self.shariah_universe))
        logger.info("Loaded sector map: %s symbols", len(self.sector_map))

        if REQUIRE_SHARIAH_WHITELIST and not self.shariah_universe:
            logger.warning("Strict Shariah mode is on, but shariah_universe.txt is empty.")

    @staticmethod
    def _load_sector_map(path: Path) -> dict[str, str]:
        if not path.exists():
            return {}
        mapping: dict[str, str] = {}
        with path.open("r", encoding="utf-8", errors="ignore") as handle:
            reader = csv.DictReader(handle)
            for row in reader:
                symbol = (row.get("symbol") or "").strip().upper()
                sector = (row.get("sector") or "Unknown").strip()
                if symbol:
                    mapping[symbol] = sector
        return mapping

    def is_shariah(self, symbol: str) -> bool:
        symbol = symbol.upper().strip()
        if REQUIRE_SHARIAH_WHITELIST:
            return symbol in self.shariah_universe
        return not self.shariah_universe or symbol in self.shariah_universe

    def sector(self, symbol: str) -> str:
        return self.sector_map.get(symbol.upper().strip(), "Unknown")


# =============================================================================
# SIMPLE SENTIMENT AND CONTEXT
# =============================================================================

class TextSentiment:
    POSITIVE = {
        "profit", "growth", "record", "higher", "increase", "dividend", "bonus",
        "approval", "contract", "award", "expansion", "upgrade", "surge",
        "strong", "beat", "positive", "recovery", "launch", "export", "buyback",
    }
    NEGATIVE = {
        "loss", "decline", "lower", "decrease", "default", "penalty", "shutdown",
        "delay", "suspend", "suspension", "fraud", "investigation", "weak",
        "miss", "negative", "resignation", "lawsuit", "fine", "ban", "halt",
    }
    HIGH_IMPORTANCE = {
        "board meeting", "financial results", "dividend", "bonus", "right shares",
        "book closure", "ex-date", "material information", "price sensitive",
        "contract", "shutdown", "merger", "acquisition", "eps", "profit", "loss",
    }

    def score(self, text: str) -> tuple[float, float, str]:
        t = text.lower()
        pos = sum(1 for w in self.POSITIVE if w in t)
        neg = sum(1 for w in self.NEGATIVE if w in t)
        imp = sum(1 for w in self.HIGH_IMPORTANCE if w in t)

        sentiment = clamp(50 + (pos - neg) * 12, 0, 100)
        importance = clamp(20 + imp * 18 + (pos + neg) * 4, 0, 100)

        event_type = "news"
        if "board meeting" in t:
            event_type = "board_meeting"
        elif "book closure" in t or "ex-date" in t or "dividend" in t:
            event_type = "dividend_or_ex_date"
        elif "financial result" in t or "eps" in t or "profit" in t or "loss" in t:
            event_type = "financial_result"
        elif "material information" in t:
            event_type = "material_information"

        return sentiment, importance, event_type


class PSXTerminalClient:
    def __init__(self) -> None:
        self.session = requests.Session()
        self.session.headers.update({"User-Agent": "PSX-Level5-Agent/1.0"})

    def get_json(self, path: str) -> Optional[Any]:
        url = f"{PSX_API_BASE.rstrip('/')}/{path.lstrip('/')}"
        try:
            r = self.session.get(url, timeout=10)
            r.raise_for_status()
            return r.json()
        except Exception as exc:
            logger.debug("API failed %s: %s", url, exc)
            return None

    def market_stats(self) -> dict[str, Any]:
        data = self.get_json(f"stats/{MARKET_TYPE}")
        return data if isinstance(data, dict) else {}


class NewsEngine:
    def __init__(self, symbols: list[str], sentiment: TextSentiment) -> None:
        self.symbols = symbols
        self.sentiment = sentiment
        self.seen: set[str] = set()

    def fetch_rss_news(self) -> list[NewsItem]:
        if not feedparser or not NEWS_RSS_URLS:
            return []

        items: list[NewsItem] = []
        for url in NEWS_RSS_URLS:
            try:
                feed = feedparser.parse(url)
                for entry in feed.entries[:30]:
                    title = getattr(entry, "title", "")
                    summary = getattr(entry, "summary", "")
                    link = getattr(entry, "link", "")
                    text = f"{title} {summary}"
                    ident = hash_text(link or text)
                    if ident in self.seen:
                        continue
                    self.seen.add(ident)
                    symbols = [s for s in self.symbols if re.search(rf"\b{re.escape(s)}\b", text, re.I)]
                    sentiment, importance, event_type = self.sentiment.score(text)
                    items.append(
                        NewsItem(
                            source="rss",
                            title=title,
                            summary=summary,
                            published_at=now_karachi(),
                            url=link,
                            symbols=symbols,
                            sentiment=sentiment,
                            importance=importance,
                            event_type=event_type,
                        )
                    )
            except Exception as exc:
                logger.debug("RSS fetch failed %s: %s", url, exc)
        return items


class PSXAnnouncementEngine:
    def __init__(self, symbols: list[str], sentiment: TextSentiment) -> None:
        self.symbols = symbols
        self.sentiment = sentiment
        self.seen: set[str] = set()
        self.session = requests.Session()
        self.session.headers.update({"User-Agent": "PSX-Level5-Agent/1.0"})

    def fetch_recent(self) -> list[NewsItem]:
        url = f"{PSX_DPS_BASE.rstrip('/')}/announcements/companies"
        try:
            r = self.session.get(url, timeout=12)
            r.raise_for_status()
            soup = BeautifulSoup(r.text, "html.parser")
            chunks: list[str] = []

            for row in soup.select("tr")[:80]:
                text = " ".join(row.get_text(" ", strip=True).split())
                if len(text) > 20:
                    chunks.append(text)

            if not chunks:
                body = " ".join(soup.get_text(" ", strip=True).split())
                if body:
                    chunks.append(body[:1000])

        except Exception as exc:
            logger.debug("PSX announcement fetch failed: %s", exc)
            return []

        items: list[NewsItem] = []
        for text in chunks:
            ident = hash_text(text)
            if ident in self.seen:
                continue
            self.seen.add(ident)

            symbols = [s for s in self.symbols if re.search(rf"\b{re.escape(s)}\b", text, re.I)]
            sentiment, importance, event_type = self.sentiment.score(text)

            items.append(
                NewsItem(
                    source="psx_announcement",
                    title=text[:180],
                    summary=text,
                    published_at=now_karachi(),
                    url=url,
                    symbols=symbols,
                    sentiment=sentiment,
                    importance=importance,
                    event_type=event_type,
                )
            )
        return items


class EventCalendar:
    def __init__(self, path: Path) -> None:
        self.path = path
        self.events = self._load_events()

    def _load_events(self) -> list[CorporateEvent]:
        if not self.path.exists():
            return []

        events: list[CorporateEvent] = []
        with self.path.open("r", encoding="utf-8", errors="ignore") as handle:
            reader = csv.DictReader(handle)
            for row in reader:
                symbol = (row.get("symbol") or "").strip().upper()
                event_type = (row.get("event_type") or "event").strip().lower()
                raw_date = (row.get("event_date") or "").strip()
                details = (row.get("details") or "").strip()

                if not symbol or not raw_date:
                    continue

                try:
                    event_date = datetime.fromisoformat(raw_date).date()
                except Exception:
                    continue

                importance = 70 if event_type in {"board_meeting", "ex_date", "result", "dividend"} else 40
                events.append(CorporateEvent(symbol, event_type, event_date, details, importance))

        return events

    def upcoming_for(self, symbol: str, days: int = 7) -> list[CorporateEvent]:
        today = now_karachi().date()
        return [
            e
            for e in self.events
            if e.symbol == symbol.upper() and today <= e.event_date <= today + timedelta(days=days)
        ]


class ContextEngine:
    def __init__(self, ref: ReferenceData, symbols: list[str]) -> None:
        self.ref = ref
        self.symbols = symbols
        self.psx = PSXTerminalClient()
        self.sentiment = TextSentiment()
        self.news = NewsEngine(symbols, self.sentiment)
        self.announcements = PSXAnnouncementEngine(symbols, self.sentiment)
        self.calendar = EventCalendar(EVENT_CALENDAR_FILE)
        self.context = MarketContext()
        self.last_refresh = datetime(1970, 1, 1, tzinfo=KARACHI_TZ)

    def refresh_if_needed(self, force: bool = False) -> MarketContext:
        age = (now_karachi() - self.last_refresh).total_seconds()
        if not force and age < REFRESH_CONTEXT_SECONDS:
            return self.context
        self.context = self.refresh()
        self.last_refresh = now_karachi()
        return self.context

    def refresh(self) -> MarketContext:
        logger.info("Refreshing market/news/event context")
        market_score, breadth_score = self._market_scores()
        sector_scores = self._sector_scores()
        news_items = self.news.fetch_rss_news() + self.announcements.fetch_recent()

        return MarketContext(
            market_score=market_score,
            market_breadth_score=breadth_score,
            sector_scores=sector_scores,
            global_macro_score=50.0,  # placeholder until you add a licensed/global API
            fipi_lipi_score=50.0,     # placeholder until you add NCCPL parsing/API
            news_items=news_items,
            corporate_events=self.calendar.events,
            refreshed_at=now_karachi(),
        )

    def _market_scores(self) -> tuple[float, float]:
        stats = self.psx.market_stats()
        if not stats:
            return 50.0, 50.0

        adv = safe_float(stats.get("advancers") or stats.get("adv") or stats.get("up"), 0)
        dec = safe_float(stats.get("decliners") or stats.get("dec") or stats.get("down"), 0)
        unchanged = safe_float(stats.get("unchanged") or stats.get("unch"), 0)
        total = adv + dec + unchanged

        breadth = 50.0 if total <= 0 else clamp((adv / total) * 100, 0, 100)
        market = clamp(45 + breadth * 0.55, 0, 100)
        return round(market, 1), round(breadth, 1)

    def _sector_scores(self) -> dict[str, float]:
        sectors = set(self.ref.sector(s) for s in self.symbols)
        return {sector: 50.0 for sector in sectors}

    def recent_news_for(self, symbol: str, minutes: int = NEWS_LOOKBACK_MINUTES) -> list[NewsItem]:
        cutoff = now_karachi() - timedelta(minutes=minutes)
        out = []
        for item in self.context.news_items:
            if item.published_at < cutoff:
                continue
            text = f"{item.title} {item.summary}"
            if symbol in item.symbols or re.search(rf"\b{re.escape(symbol)}\b", text, re.I):
                out.append(item)
        return out

    def events_for(self, symbol: str, days: int = 7) -> list[CorporateEvent]:
        return self.calendar.upcoming_for(symbol, days)


# =============================================================================
# TICK PARSING
# =============================================================================

def first_present(data: Dict[str, Any], keys: Iterable[str]) -> Any:
    for key in keys:
        if key in data and data[key] not in (None, ""):
            return data[key]
    return None


def normalize_tick(raw: Dict[str, Any]) -> Optional[Tick]:
    symbol = first_present(raw, ["symbol", "s", "ticker", "code", "SYM", "SYMBOL"])
    if not symbol:
        return None
    symbol = str(symbol).upper().strip()

    price = safe_float(
        first_present(raw, ["price", "last", "lastPrice", "close", "rate", "p", "LAST"]),
        0.0,
    )
    if price <= 0:
        return None

    volume = safe_float(first_present(raw, ["volume", "vol", "v", "turnover", "VOLUME"]), 0.0)

    bid_raw = first_present(raw, ["bid", "bestBid", "b", "BID"])
    ask_raw = first_present(raw, ["ask", "bestAsk", "a", "ASK"])
    bid = safe_float(bid_raw, math.nan) if bid_raw is not None else None
    ask = safe_float(ask_raw, math.nan) if ask_raw is not None else None

    timestamp = now_karachi()
    raw_time = first_present(raw, ["timestamp", "time", "t", "datetime"])
    if raw_time:
        try:
            if isinstance(raw_time, (int, float)):
                ts = raw_time / 1000 if raw_time > 10_000_000_000 else raw_time
                timestamp = datetime.fromtimestamp(ts, tz=KARACHI_TZ)
            elif isinstance(raw_time, str):
                timestamp = datetime.fromisoformat(raw_time.replace("Z", "+00:00")).astimezone(KARACHI_TZ)
        except Exception:
            pass

    return Tick(symbol=symbol, price=price, volume=volume, bid=bid, ask=ask, timestamp=timestamp)


def extract_ticks(message: Any) -> list[Tick]:
    if isinstance(message, str):
        try:
            message = json.loads(message)
        except Exception:
            return []

    candidates: list[Any] = []

    if isinstance(message, list):
        candidates = message
    elif isinstance(message, dict):
        for key in ["data", "payload", "ticks", "marketData", "items", "results"]:
            value = message.get(key)
            if isinstance(value, list):
                candidates.extend(value)
            elif isinstance(value, dict):
                candidates.append(value)
        candidates.append(message)

    ticks: list[Tick] = []
    for item in candidates:
        if isinstance(item, dict):
            tick = normalize_tick(item)
            if tick:
                ticks.append(tick)

    return ticks


# =============================================================================
# AI SCORING
# =============================================================================

class OptionalMLModel:
    def __init__(self, path: Path) -> None:
        self.model = None
        if joblib and path.exists():
            try:
                self.model = joblib.load(path)
                logger.info("Loaded AI model from %s", path)
            except Exception as exc:
                logger.warning("Could not load AI model: %s", exc)

    def score(self, features: dict[str, float]) -> float:
        if self.model is None:
            return 50.0

        keys = sorted(features)
        x = np.array([[features[k] for k in keys]], dtype=float)

        try:
            if hasattr(self.model, "predict_proba"):
                proba = self.model.predict_proba(x)[0]
                return float(proba[-1] * 100)

            pred = self.model.predict(x)[0]
            return float(clamp(pred * 100 if pred <= 1 else pred, 0, 100))

        except Exception as exc:
            logger.debug("Model scoring failed: %s", exc)
            return 50.0


class AIScoringEngine:
    def __init__(self, ref: ReferenceData, context_engine: ContextEngine) -> None:
        self.ref = ref
        self.context_engine = context_engine
        self.ml_model = OptionalMLModel(AI_MODEL_PATH)

    def score_symbol(self, symbol: str, state: SymbolState, context: MarketContext) -> Optional[FeatureVector]:
        if not state.ready():
            return None

        if not self.ref.is_shariah(symbol):
            return None

        ticks = list(state.ticks)
        latest = ticks[-1]
        prices = state.prices()
        volumes = state.volumes()
        sector = self.ref.sector(symbol)

        reasons = ["Shariah whitelist passed"]
        dangers: list[str] = []

        if latest.price < MIN_PRICE:
            return None

        spread = latest.spread_pct
        spread_value = spread if spread is not None and not math.isnan(spread) else MAX_SPREAD_PCT / 2

        liquidity_ok = latest.volume <= 0 or latest.trade_value >= MIN_TRADE_VALUE_PKR
        liquidity_score = 80 if liquidity_ok else 20

        if spread is not None and spread > MAX_SPREAD_PCT:
            dangers.append(f"Spread too wide: {spread:.2f}%")
        if not liquidity_ok:
            dangers.append("Liquidity/trade value below threshold")

        recent_start_price = prices[-min(10, len(prices))]
        recent_momentum = pct_change(latest.price, recent_start_price)

        previous_high = max(prices[:-1])
        breakout_strength = pct_change(latest.price, previous_high)

        old_volumes = [v for v in volumes[:-1] if v >= 0]
        avg_volume = statistics.mean(old_volumes) if old_volumes else 0
        volume_multiple = latest.volume / avg_volume if avg_volume > 0 else 0

        momentum_score = clamp((recent_momentum / max(MOMENTUM_PCT, 0.01)) * 45, 0, 45)
        breakout_score = clamp((breakout_strength / max(BREAKOUT_BUFFER_PCT, 0.01)) * 35, 0, 35)
        stability_score = 20 if latest.price >= prices[-min(5, len(prices))] else 8
        technical_score = clamp(momentum_score + breakout_score + stability_score, 0, 100)
        volume_score = clamp((volume_multiple / max(VOLUME_SPIKE_MULTIPLE, 0.01)) * 100, 0, 100)

        if recent_momentum >= MOMENTUM_PCT:
            reasons.append(f"Momentum positive: +{recent_momentum:.2f}%")
        if volume_multiple >= VOLUME_SPIKE_MULTIPLE:
            reasons.append(f"Volume spike: {volume_multiple:.2f}x average")
        if breakout_strength >= BREAKOUT_BUFFER_PCT:
            reasons.append(f"Breakout strength: +{breakout_strength:.2f}% above rolling high")

        market_score = (context.market_score * 0.7) + (context.market_breadth_score * 0.3)
        if market_score < 40:
            dangers.append(f"Market context weak: {market_score:.1f}")
        else:
            reasons.append(f"Market context supportive: {market_score:.1f}")

        sector_score = context.sector_scores.get(sector, 50.0)
        if sector_score < 40:
            dangers.append(f"Sector weak: {sector} {sector_score:.1f}")

        recent_news = self.context_engine.recent_news_for(symbol, NEWS_LOOKBACK_MINUTES)
        if recent_news:
            weighted = sum(n.sentiment * max(n.importance, 1) for n in recent_news)
            denom = sum(max(n.importance, 1) for n in recent_news)
            news_score = weighted / denom if denom else 50.0
            top = sorted(recent_news, key=lambda n: n.importance, reverse=True)[0]
            reasons.append(f"Recent news/announcement: {top.event_type}, sentiment {news_score:.1f}")
            if news_score < 40 and top.importance >= 50:
                dangers.append(f"Negative recent news: {top.title[:90]}")
        else:
            news_score = 50.0
            reasons.append("No negative stock-specific news detected recently")

        event_score = 70.0
        today = now_karachi().date()
        for event in self.context_engine.events_for(symbol, 10):
            days_away = (event.event_date - today).days
            if event.event_type in {"board_meeting", "result"} and days_away <= BOARD_MEETING_DANGER_DAYS:
                event_score -= 20
                dangers.append(f"Board/result event near: {event.event_type} on {event.event_date}")
            if event.event_type in {"ex_date", "book_closure", "dividend"} and days_away <= EX_DATE_DANGER_DAYS:
                event_score -= 25
                dangers.append(f"Ex-date/dividend risk near: {event.event_type} on {event.event_date}")
        event_score = clamp(event_score, 0, 100)

        global_macro_score = context.global_macro_score
        fipi_lipi_score = context.fipi_lipi_score
        shariah_score = 100.0

        risk_score = 100.0
        if spread is not None:
            risk_score -= clamp((spread / max(MAX_SPREAD_PCT, 0.01)) * 25, 0, 35)
        if not liquidity_ok:
            risk_score -= 35
        risk_score -= len(dangers) * 8
        risk_score = clamp(risk_score, 0, 100)

        model_inputs = {
            "technical_score": technical_score,
            "volume_score": volume_score,
            "market_score": market_score,
            "sector_score": sector_score,
            "news_score": news_score,
            "event_score": event_score,
            "global_macro_score": global_macro_score,
            "fipi_lipi_score": fipi_lipi_score,
            "risk_score": risk_score,
            "spread_pct": spread_value,
            "liquidity_score": liquidity_score,
            "recent_momentum": recent_momentum,
            "volume_multiple": volume_multiple,
            "breakout_strength": breakout_strength,
        }

        historical_model_score = self.ml_model.score(model_inputs)

        final_confidence = (
            technical_score * 0.20
            + volume_score * 0.15
            + news_score * 0.15
            + sector_score * 0.10
            + market_score * 0.10
            + event_score * 0.10
            + global_macro_score * 0.08
            + shariah_score * 0.07
            + historical_model_score * 0.05
            + fipi_lipi_score * 0.05
            + risk_score * 0.05
        )
        final_confidence = clamp(final_confidence, 0, 100)

        if spread is not None and spread > MAX_SPREAD_PCT:
            final_confidence = min(final_confidence, 55)
        if not liquidity_ok:
            final_confidence = min(final_confidence, 55)
        if any("Negative recent news" in d for d in dangers):
            final_confidence = min(final_confidence, 60)
        if any("Ex-date" in d or "dividend risk" in d for d in dangers):
            final_confidence = min(final_confidence, 65)
        if market_score < 35:
            final_confidence = min(final_confidence, 58)

        return FeatureVector(
            symbol=symbol,
            sector=sector,
            price=latest.price,
            spread_pct=round(spread_value, 3),
            liquidity_score=liquidity_score,
            technical_score=round(technical_score, 1),
            volume_score=round(volume_score, 1),
            market_score=round(market_score, 1),
            sector_score=round(sector_score, 1),
            news_score=round(news_score, 1),
            event_score=round(event_score, 1),
            global_macro_score=round(global_macro_score, 1),
            fipi_lipi_score=round(fipi_lipi_score, 1),
            shariah_score=shariah_score,
            risk_score=round(risk_score, 1),
            historical_model_score=round(historical_model_score, 1),
            final_confidence=round(final_confidence, 1),
            reasons=reasons[:8],
            dangers=dangers[:8],
        )


# =============================================================================
# ALERTS
# =============================================================================

def send_telegram(text: str) -> None:
    if not TELEGRAM_BOT_TOKEN or not TELEGRAM_CHAT_ID:
        logger.warning("Telegram not configured. Alert was:\n%s", text)
        return

    url = f"https://api.telegram.org/bot{TELEGRAM_BOT_TOKEN}/sendMessage"
    payload = {
        "chat_id": TELEGRAM_CHAT_ID,
        "text": text,
        "parse_mode": "HTML",
        "disable_web_page_preview": True,
    }

    try:
        r = requests.post(url, json=payload, timeout=10)
        r.raise_for_status()
    except Exception as exc:
        logger.exception("Telegram send failed: %s", exc)


def entry_zone(price: float) -> tuple[float, float]:
    return price * (1 - ENTRY_ZONE_BUFFER_PCT / 100), price * (1 + ENTRY_ZONE_BUFFER_PCT / 100)


def risk_plan(current_price: float) -> tuple[float, float, float, float]:
    risk_per_share = current_price * (STOP_LOSS_PCT / 100)
    stop = current_price - risk_per_share
    target1 = current_price + risk_per_share * TARGET1_R
    target2 = current_price + risk_per_share * TARGET2_R
    return stop, target1, target2, TARGET1_R


def build_watch_alert(setup: PendingSetup) -> str:
    f = setup.features
    reasons = "\n".join(f"• {r}" for r in f.reasons[:6]) or "• Setup detected"
    dangers = "\n".join(f"• {d}" for d in f.dangers[:5]) or "• No major danger detected yet"

    return (
        f"👀 <b>PSX SHARIAH AI WATCH: {setup.symbol}</b>\n"
        f"Confidence: <b>{setup.confidence:.1f}%</b>\n"
        f"Sector: {f.sector}\n"
        f"Entry zone: <b>{setup.entry_low:.2f} - {setup.entry_high:.2f}</b>\n"
        f"Hold rule: price must stay above <b>{setup.entry_low:.2f}</b> for "
        f"{HOLD_CONFIRM_TICKS} ticks and about {HOLD_CONFIRM_SECONDS}s.\n\n"
        f"Scores:\n"
        f"• Technical {f.technical_score:.1f} | Volume {f.volume_score:.1f} | News {f.news_score:.1f}\n"
        f"• Market {f.market_score:.1f} | Sector {f.sector_score:.1f} | Event {f.event_score:.1f}\n"
        f"• Global {f.global_macro_score:.1f} | Risk {f.risk_score:.1f} | ML {f.historical_model_score:.1f}\n\n"
        f"Why watch:\n{reasons}\n\n"
        f"Risks:\n{dangers}\n\n"
        f"No trade yet. Wait for confirmation."
    )


def build_trade_alert(setup: PendingSetup, current_price: float) -> str:
    f = setup.features
    stop, target1, target2, rr = risk_plan(current_price)
    strength = "HIGH-CONFIDENCE" if f.final_confidence >= STRONG_TRADE_CONFIDENCE else "CONFIRMED"
    reasons = "\n".join(f"• {r}" for r in f.reasons[:7]) or "• Confirmed setup"
    dangers = "\n".join(f"• {d}" for d in f.dangers[:5]) or "• No major danger detected at confirmation"

    return (
        f"🚨 <b>PSX SHARIAH AI TRADE ALERT: {setup.symbol}</b>\n"
        f"Status: <b>{strength} - PRICE HELD ABOVE ENTRY</b>\n"
        f"Trade type: Intraday / short-term momentum\n"
        f"Confidence: <b>{f.final_confidence:.1f}%</b>\n"
        f"Sector: {f.sector}\n\n"
        f"Entry zone: <b>{setup.entry_low:.2f} - {setup.entry_high:.2f}</b>\n"
        f"Current price: <b>{current_price:.2f}</b>\n"
        f"Stop loss: <b>{stop:.2f}</b> (-{STOP_LOSS_PCT:.2f}%)\n"
        f"Target 1: <b>{target1:.2f}</b> ({TARGET1_R:.2f}R)\n"
        f"Target 2: <b>{target2:.2f}</b> ({TARGET2_R:.2f}R)\n"
        f"Reward/Risk: <b>{rr:.2f}R+</b>\n"
        f"Max account risk idea: {MAX_POSITION_RISK_PCT:.2f}%\n\n"
        f"Confirmation:\n"
        f"• Price stayed above {setup.entry_low:.2f}\n"
        f"• Hold ticks: {setup.hold_ticks}\n"
        f"• Hold window target: {HOLD_CONFIRM_SECONDS}s\n\n"
        f"AI reasons:\n{reasons}\n\n"
        f"Failure risks:\n{dangers}\n\n"
        f"Invalidation: avoid/exit if price falls below entry zone, market reverses, "
        f"bad news appears, or volume dries up. Signal only, not financial advice."
    )


def build_danger_alert(symbol: str, reasons: list[str]) -> str:
    body = "\n".join(f"• {r}" for r in reasons[:8])
    return f"⚠️ <b>PSX AI DANGER / AVOID: {symbol}</b>\n{body}\nFollow stop-loss if already in trade."


# =============================================================================
# MAIN AGENT
# =============================================================================

class PSXLevel5Agent:
    def __init__(self) -> None:
        self.ref = ReferenceData()
        self.symbols = WATCHLIST
        self.context_engine = ContextEngine(self.ref, self.symbols)
        self.scorer = AIScoringEngine(self.ref, self.context_engine)
        self.states: Dict[str, SymbolState] = defaultdict(SymbolState)
        self.stop_event = asyncio.Event()

    def stop(self) -> None:
        self.stop_event.set()

    async def run(self) -> None:
        logger.info("Starting PSX Level-5 Shariah AI Market Intelligence Agent")
        logger.info("Strict Shariah mode: %s", REQUIRE_SHARIAH_WHITELIST)
        logger.info("Market open now: %s", is_psx_regular_market_open())

        self.context_engine.refresh_if_needed(force=True)

        await self.stream_loop()

    async def stream_loop(self) -> None:
        backoff = 2

        while not self.stop_event.is_set():
            try:
                logger.info("Connecting WebSocket: %s", PSX_WS_URL)

                async with websockets.connect(PSX_WS_URL, ping_interval=20, ping_timeout=20) as ws:
                    await ws.send(
                        json.dumps(
                            {
                                "type": "subscribe",
                                "subscriptionType": "marketData",
                                "params": {"marketType": MARKET_TYPE},
                            }
                        )
                    )

                    send_telegram("✅ PSX Level-5 Shariah AI agent connected. Alert-only mode active.")
                    backoff = 2

                    async for raw_message in ws:
                        if self.stop_event.is_set():
                            break
                        await self.handle_message(raw_message)

            except Exception as exc:
                logger.exception("Stream error: %s", exc)
                await asyncio.sleep(min(backoff, 60))
                backoff *= 2

    async def handle_message(self, raw_message: Any) -> None:
        if not is_psx_regular_market_open():
            return

        context = self.context_engine.refresh_if_needed()
        ticks = extract_ticks(raw_message)

        if not ticks:
            return

        for tick in ticks:
            symbol = tick.symbol.upper()

            if self.symbols and symbol not in self.symbols:
                continue

            if not self.ref.is_shariah(symbol):
                continue

            state = self.states[symbol]
            state.add(tick)

            danger_reasons = self.detect_danger(symbol, state, context)
            if danger_reasons and state.pending:
                send_telegram(build_danger_alert(symbol, danger_reasons))
                state.pending = None
                continue

            trade_alert = self.update_pending(symbol, state, tick)
            if trade_alert:
                send_telegram(trade_alert)
                state.last_alert_at = tick.timestamp
                continue

            if state.pending is None and self.cooldown_ok(state, tick.timestamp):
                setup = self.try_create_setup(symbol, state, context)
                if setup:
                    state.pending = setup
                    send_telegram(build_watch_alert(setup))

    def cooldown_ok(self, state: SymbolState, now: datetime) -> bool:
        return now - state.last_alert_at >= timedelta(minutes=ALERT_COOLDOWN_MINUTES)

    def try_create_setup(self, symbol: str, state: SymbolState, context: MarketContext) -> Optional[PendingSetup]:
        features = self.scorer.score_symbol(symbol, state, context)

        if not features:
            return None

        if features.final_confidence < WATCH_CONFIDENCE:
            return None

        if features.dangers and features.final_confidence < TRADE_CONFIDENCE:
            return None

        prices = state.prices()
        latest = state.ticks[-1]
        previous_high = max(prices[:-1])
        breakout_strength = pct_change(latest.price, previous_high)

        technical_trigger = (
            breakout_strength >= BREAKOUT_BUFFER_PCT
            and features.technical_score >= 60
            and features.volume_score >= 55
        )

        if not technical_trigger:
            return None

        entry_low, entry_high = entry_zone(latest.price)

        return PendingSetup(
            symbol=symbol,
            setup_time=latest.timestamp,
            setup_price=latest.price,
            entry_low=entry_low,
            entry_high=entry_high,
            confidence=features.final_confidence,
            features=features,
        )

    def update_pending(self, symbol: str, state: SymbolState, tick: Tick) -> Optional[str]:
        pending = state.pending

        if not pending:
            return None

        age = tick.timestamp - pending.setup_time

        if age > timedelta(seconds=MAX_PENDING_SECONDS):
            state.pending = None
            return None

        pending.last_seen = tick.timestamp

        if tick.price < pending.entry_low:
            state.pending = None
            return build_danger_alert(
                symbol,
                [f"Price failed hold rule: {tick.price:.2f} below {pending.entry_low:.2f}"],
            )

        pending.hold_ticks += 1

        held_long_enough = age >= timedelta(seconds=HOLD_CONFIRM_SECONDS)
        enough_ticks = pending.hold_ticks >= HOLD_CONFIRM_TICKS

        if held_long_enough and enough_ticks and pending.features.final_confidence >= TRADE_CONFIDENCE:
            state.pending = None
            return build_trade_alert(pending, tick.price)

        return None

    def detect_danger(self, symbol: str, state: SymbolState, context: MarketContext) -> list[str]:
        dangers: list[str] = []

        recent_news = self.context_engine.recent_news_for(symbol, NEWS_LOOKBACK_MINUTES)

        for item in recent_news:
            if item.sentiment < 35 and item.importance >= 50:
                dangers.append(f"Negative fresh news/announcement: {item.title[:100]}")

        if context.market_score < 30:
            dangers.append(f"Market sentiment very weak: {context.market_score:.1f}")

        if state.ticks:
            latest = state.ticks[-1]
            if latest.spread_pct is not None and latest.spread_pct > MAX_SPREAD_PCT:
                dangers.append(f"Spread widened to {latest.spread_pct:.2f}%")

        return dangers


# =============================================================================
# TRAINING HELPER
# =============================================================================

def train_example_model(csv_path: str, out_path: str = "models/psx_ai_model.joblib") -> None:
    """
    Train a starter model.

    CSV must include numeric feature columns and:
        target_hit_before_stop

    1 means Target 1 hit before stop-loss.
    0 means stop-loss hit before Target 1.
    """
    if joblib is None:
        raise RuntimeError("joblib is required. Install with: pip install joblib")

    from sklearn.ensemble import HistGradientBoostingClassifier
    from sklearn.model_selection import train_test_split
    from sklearn.metrics import classification_report

    df = pd.read_csv(csv_path)
    target = "target_hit_before_stop"

    if target not in df.columns:
        raise ValueError(f"CSV must include target column: {target}")

    feature_cols = [c for c in df.columns if c != target and pd.api.types.is_numeric_dtype(df[c])]

    if not feature_cols:
        raise ValueError("No numeric feature columns found.")

    x = df[feature_cols].fillna(0)
    y = df[target].astype(int)

    if len(df) < 20:
        print("Warning: very small dataset. Good training needs many examples, ideally 200+.")

    x_train, x_test, y_train, y_test = train_test_split(x, y, test_size=0.25, shuffle=False)

    model = HistGradientBoostingClassifier(max_iter=200, learning_rate=0.05)
    model.fit(x_train, y_train)

    preds = model.predict(x_test)
    print(classification_report(y_test, preds))

    out = Path(out_path)
    out.parent.mkdir(parents=True, exist_ok=True)
    joblib.dump(model, out)

    print(f"Saved model to {out}")


# =============================================================================
# ENTRYPOINT
# =============================================================================

async def main() -> None:
    agent = PSXLevel5Agent()

    loop = asyncio.get_running_loop()

    for sig in (signal.SIGINT, signal.SIGTERM):
        try:
            loop.add_signal_handler(sig, agent.stop)
        except NotImplementedError:
            pass

    await agent.run()


if __name__ == "__main__":
    asyncio.run(main())
